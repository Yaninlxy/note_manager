import unittest
from data import save_notes_to_file, load_notes_from_file
from utils.validators import validate_status, generate_unique_id

class TestNoteManager(unittest.TestCase):

    def test_save_and_load_notes(self):
        notes = [{'id': '123', 'title': 'Test Note', 'content': 'Test Content', 'status': 'новая'}]
        save_notes_to_file(notes, 'test_notes.json')
        loaded_notes = load_notes_from_file('test_notes.json')
        self.assertEqual(notes, loaded_notes)

    def test_validate_status(self):
        self.assertTrue(validate_status('новая'))
        self.assertFalse(validate_status('unknown'))

    def test_generate_unique_id(self):
        id1 = generate_unique_id()
        id2 = generate_unique_id()
        self.assertNotEqual(id1, id2)

if __name__ == '__main__':
    unittest.main()
