# main.py
from interface import display_notes, add_new_note
from data import load_notes_from_file

def main():
    notes = load_notes_from_file('notes.json')
    
    while True:
        print("\nМеню:")
        print("1. Просмотр заметок")
        print("2. Добавить заметку")
        print("3. Выйти")
        
        choice = input("Выберите действие: ")
        
        if choice == '1':
            display_notes(notes)
        elif choice == '2':
            add_new_note(notes, 'notes.json')
        elif choice == '3':
            break
        else:
            print("Некорректный выбор. Попробуйте снова.")

if __name__ == '__main__':
    main()
