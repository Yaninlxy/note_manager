import json

def save_notes_to_file(notes, file_path):
    try:
        with open(file_path, 'w', encoding='utf-8') as file:
            json.dump(notes, file, ensure_ascii=False, indent=4)
    except Exception as e:
        print(f"Ошибка при сохранении файла: {e}")

def load_notes_from_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            return json.load(file)  # Преобразует JSON в Python-объекты
    except (FileNotFoundError, json.JSONDecodeError):
        return []  # Если файла нет или он пустой, возвращается пустой список
