from .user_interface import display_notes, add_new_note
