from data.file_handling import save_notes_to_file
from utils.validators import validate_status, generate_unique_id

def display_notes(notes):
    if not notes:
        print("Заметок нет.")
    else:
        print("Ваши заметки:")
        for idx, note in enumerate(notes, 1):
            print(f"{idx}. ID: {note['id']}")
            print(f"   Заголовок: {note['title']}")
            print(f"   Содержание: {note['content']}")
            print(f"   Статус: {note['status']}")
            print("-" * 40)  # Разделитель для удобства чтения

def add_new_note(notes, file_path):
    title = input("Введите заголовок заметки: ")
    content = input("Введите содержание заметки: ")

    while True:
        status = input("Введите статус (новая, в процессе, выполнена): ")
        if validate_status(status):
            break
        else:
            print("Некорректный статус. Попробуйте снова.")

    unique_id = generate_unique_id()
    
    new_note = {
        'id': unique_id,
        'title': title,
        'content': content,
        'status': status
    }
    
    notes.append(new_note)
    save_notes_to_file(notes, file_path)
    print("Заметка успешно добавлена!")
